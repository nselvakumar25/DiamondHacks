By installing or using this font, you are agree to the Product Usage Agreement:

1. This font for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You are requires a license for PROMOTIONAL or COMMERCIAL use.

3. CONTACT ME before any Promotional or Commercial Use!

>>> blankids.co@gmail.com <<<

Paypal account for donation : https://www.paypal.me/blankids

Link to purchase full version and commercial license:
https://creativemarket.com/bangkit.tri.setiadi/2278992-Old-Finlander

Please visit our store for more great fonts : 
https://creativemarket.com/bangkit.tri.setiadi

Thanks,
blankids Studio